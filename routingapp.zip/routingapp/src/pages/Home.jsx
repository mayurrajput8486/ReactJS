import Slider from "./Slider"
import Courses from "./Courses"
const Home = () => {
    return (
        <div>
            <Slider/>
            <Courses/>
        </div>
    )
}

export default Home