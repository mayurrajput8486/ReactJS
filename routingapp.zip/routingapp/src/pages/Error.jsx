import clienterror from '../assets/error.gif'
const Error = () => {
  return (
    <div className='text-center'>
        <img src={clienterror} alt='404 client error' width='100%' height='625px'></img>
    </div>
  )
}

export default Error