const Update = () => {
  return (
    <div>
        <h2>Update Student Data</h2>
    </div>
  )
}

export default Update