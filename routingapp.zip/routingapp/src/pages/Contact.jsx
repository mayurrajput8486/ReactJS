const Contact = () => {
  return (
    <div>Contact</div>
  )
}

export default Contact