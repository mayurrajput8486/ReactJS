

const Delete = () => {
  return (
    <div>
        <h2>Delete Record</h2>
    </div>
  )
}

export default Delete